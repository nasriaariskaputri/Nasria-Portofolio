-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Jul 2025 pada 14.34
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cd_rental`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `booking`
--

CREATE TABLE `booking` (
  `id_booking` varchar(20) NOT NULL,
  `tgl_booking` datetime NOT NULL,
  `batas_ambil` date NOT NULL,
  `id_user` int(11) NOT NULL,
  `durasi` int(11) DEFAULT 1,
  `total_bayar` int(11) DEFAULT 0,
  `status_pembayaran` varchar(20) DEFAULT 'Menunggu Pembayaran',
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `booking`
--

INSERT INTO `booking` (`id_booking`, `tgl_booking`, `batas_ambil`, `id_user`, `durasi`, `total_bayar`, `status_pembayaran`, `metode_pembayaran`, `bukti_pembayaran`) VALUES
('11072025001', '2025-07-11 17:04:00', '2025-07-13', 3, 1, 0, 'Menunggu Pembayaran', NULL, NULL),
('13072025002', '2025-07-13 17:08:36', '2025-07-15', 4, 1, 0, 'Menunggu Pembayaran', NULL, NULL),
('13072025003', '2025-07-13 19:07:52', '2025-07-23', 5, 10, 200000, 'Menunggu Pembayaran', NULL, NULL),
('13072025004', '2025-07-13 19:08:36', '2025-07-15', 5, 2, 0, 'Menunggu Pembayaran', NULL, NULL),
('13072025005', '2025-07-13 19:15:14', '2025-07-25', 5, 12, 120000, 'Menunggu Pembayaran', NULL, NULL),
('13072025006', '2025-07-13 19:21:26', '2025-07-14', 5, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025007', '2025-07-13 19:22:48', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025008', '2025-07-13 19:40:28', '2025-07-25', 4, 12, 240000, 'Menunggu Pembayaran', NULL, NULL),
('13072025009', '2025-07-13 19:40:49', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025010', '2025-07-13 19:44:24', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025011', '2025-07-13 19:44:56', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025012', '2025-07-13 19:50:39', '2025-07-14', 4, 1, 20000, 'Menunggu Pembayaran', NULL, NULL),
('13072025013', '2025-07-13 19:52:26', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025014', '2025-07-13 20:02:50', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', NULL, NULL),
('13072025015', '2025-07-13 20:16:39', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_ovo', NULL),
('13072025016', '2025-07-13 20:17:03', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_dana', NULL),
('13072025017', '2025-07-13 20:27:01', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_ovo', NULL),
('13072025018', '2025-07-13 20:29:03', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_dana', NULL),
('13072025019', '2025-07-13 20:29:36', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'transfer_bank', NULL),
('13072025020', '2025-07-13 20:31:06', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_ovo', NULL),
('13072025021', '2025-07-13 20:43:21', '2025-07-14', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_ovo', NULL),
('14072025022', '2025-07-14 21:59:28', '2025-07-15', 4, 1, 10000, 'Sudah Bayar', 'ewallet_ovo', NULL),
('17072025023', '2025-07-17 13:34:33', '2025-07-18', 4, 1, 10000, 'Sudah Bayar', 'ewallet_ovo', 'bukti_1752752216.png'),
('17072025024', '2025-07-17 13:38:16', '2025-07-29', 4, 12, 120000, 'Sudah Bayar', 'ewallet_ovo', 'bukti_1752752302.png'),
('17072025025', '2025-07-17 13:45:01', '2025-07-18', 4, 1, 10000, 'Sudah Bayar', 'ewallet_ovo', 'bukti_1752752714.png'),
('17072025026', '2025-07-17 13:48:22', '2025-08-16', 4, 30, 600000, 'Sudah Bayar', 'ewallet_dana', 'bukti_1752752908.png'),
('17072025027', '2025-07-17 14:20:42', '2025-07-18', 4, 1, 10000, 'Menunggu Pembayaran', 'ewallet_dana', 'bukti_1752754865.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `booking_detail`
--

CREATE TABLE `booking_detail` (
  `id_booking` varchar(20) NOT NULL,
  `id_cd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `booking_detail`
--

INSERT INTO `booking_detail` (`id_booking`, `id_cd`) VALUES
('11072025001', 2),
('13072025002', 6),
('13072025002', 5),
('13072025003', 6),
('13072025003', 7),
('13072025003', 6),
('13072025004', 6),
('13072025005', 6),
('13072025003', 6),
('13072025004', 6),
('13072025005', 6),
('13072025006', 6),
('13072025002', 6),
('13072025007', 6),
('13072025008', 4),
('13072025008', 6),
('13072025009', 5),
('13072025010', 7),
('13072025011', 6),
('13072025012', 4),
('13072025012', 5),
('13072025013', 6),
('13072025014', 6),
('13072025015', 6),
('13072025016', 6),
('13072025017', 6),
('13072025018', 5),
('13072025019', 5),
('13072025020', 5),
('13072025021', 6),
('14072025022', 4),
('17072025023', 5),
('17072025024', 6),
('17072025025', 5),
('17072025026', 8),
('17072025026', 6),
('17072025027', 7);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cd_film`
--

CREATE TABLE `cd_film` (
  `id` int(11) NOT NULL,
  `judul_cd` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `sutradara` varchar(128) NOT NULL,
  `penerbit` varchar(128) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `stok` int(5) NOT NULL DEFAULT 0,
  `dipinjam` int(5) NOT NULL DEFAULT 0,
  `dibooking` int(5) NOT NULL DEFAULT 0,
  `image` varchar(128) DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `cd_film`
--

INSERT INTO `cd_film` (`id`, `judul_cd`, `id_kategori`, `sutradara`, `penerbit`, `tahun`, `kode`, `stok`, `dipinjam`, `dibooking`, `image`) VALUES
(4, 'Ao haru Ride', 5, '', '', '2020', '', 11, 0, 1, 'cd_1752234954.jpeg'),
(5, 'KKN Desa Penari', 4, '', '', '2023', '', 14, 0, 1, 'cd_1752234988.jpeg'),
(6, 'Fast And Furios', 1, '', '', '2017', '', 11, 0, 1, 'cd_1752235064.jpeg'),
(7, 'Demon Slayer \" Mugen Train\"', 1, '', '', '2024', '', 20, 0, 0, 'cd_1752235122.jpeg'),
(8, 'Junji ito', 4, '', '', '2019', '', 30, 0, 0, 'cd_1752665690.jpeg');

--
-- Trigger `cd_film`
--
DELIMITER $$
CREATE TRIGGER `log_tambah_cd` AFTER INSERT ON `cd_film` FOR EACH ROW BEGIN
  INSERT INTO log_cd (pesan_log, waktu_log)
  VALUES (CONCAT('CD "', NEW.judul_cd, '" ditambahkan.'), NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pinjam`
--

CREATE TABLE `detail_pinjam` (
  `no_pinjam` varchar(20) NOT NULL,
  `id_cd` int(11) NOT NULL,
  `denda` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `kategori` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id`, `kategori`) VALUES
(1, 'Action'),
(2, 'Drama'),
(3, 'Comedy'),
(4, 'Horror'),
(5, 'percintaan'),
(6, 'Thriller'),
(7, 'slice of life');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_cd`
--

CREATE TABLE `log_cd` (
  `id_log` int(11) NOT NULL,
  `pesan_log` text DEFAULT NULL,
  `waktu_log` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `log_cd`
--

INSERT INTO `log_cd` (`id_log`, `pesan_log`, `waktu_log`) VALUES
(1, 'CD \"Junji ito\" ditambahkan.', '2025-07-16 18:34:50');

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id`, `menu`) VALUES
(1, 'Dashboard'),
(2, 'CD'),
(3, 'Pelanggan'),
(4, 'Transaksi'),
(5, 'Laporan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pinjam`
--

CREATE TABLE `pinjam` (
  `no_pinjam` varchar(20) NOT NULL,
  `id_booking` varchar(20) DEFAULT NULL,
  `tgl_pinjam` date NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl_kembali` date NOT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  `status` varchar(15) NOT NULL,
  `total_denda` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `role`
--

INSERT INTO `role` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'Pelanggan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `temp`
--

CREATE TABLE `temp` (
  `id_cd` int(11) NOT NULL,
  `judul_cd` varchar(255) NOT NULL,
  `id_user` int(11) NOT NULL,
  `email_user` varchar(128) NOT NULL,
  `tgl_booking` datetime NOT NULL,
  `image` varchar(255) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `genre` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `temp`
--

INSERT INTO `temp` (`id_cd`, `judul_cd`, `id_user`, `email_user`, `tgl_booking`, `image`, `tahun`, `genre`) VALUES
(6, 'Fast And Furios', 4, 'lili@gmail.com', '2025-07-17 19:19:51', 'cd_1752235064.jpeg', '2017', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_cd` int(11) NOT NULL,
  `durasi` int(11) DEFAULT NULL,
  `total_bayar` int(11) DEFAULT NULL,
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `tanggal` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) DEFAULT 'default.jpg',
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `tanggal_input` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `alamat`, `email`, `image`, `password`, `role_id`, `is_active`, `tanggal_input`) VALUES
(1, 'nasria ariska putri', 'jl, haji mawi rt 11/03, parung , bogor, Jawa Barat', 'nasriaariskaputri003@gmail.com', 'default.jpg', '$2y$10$SJU/c6Tc292xUvkHSBNQLepCKzfKzjYUwQs2RETThHthcv69joL7O', 2, 1, 1752158452),
(3, 'nasria ariska putri', 'jl, haji mawi rt 11/03, parung , bogor, Jawa Barat', 'nanas@gmail.com', 'default.jpg', '$2y$10$W2O4sqo2GTe/LBj7O.9oL.ehl4Qr8VSKCJlT3saDuG5ymb0y1ecbK', 2, 1, 1752226593),
(4, 'lili', 'jl, haji mawi rt 11/03, parung , bogor, Jawa Barat', 'lili@gmail.com', 'default.jpg', '$2y$10$18BMshL0LbIBdfDsAFGVZO9VQOQkEA1CgK3heVHJjMaTTTUu0GzwC', 2, 1, 1752400864),
(5, 'nasria ariska putri', 'jl, haji mawi rt 11/03, parung , bogor, Jawa Barat', 'n@gmail.com', 'default.jpg', '$2y$10$GJ9SAICe.U8Gn18m80vIp.ZRYdSoWyQBbqC2n34gXxj4CjcXBeP8C', 1, 1, 1752402867);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id_booking`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `booking_detail`
--
ALTER TABLE `booking_detail`
  ADD KEY `id_booking` (`id_booking`),
  ADD KEY `id_cd` (`id_cd`);

--
-- Indeks untuk tabel `cd_film`
--
ALTER TABLE `cd_film`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `detail_pinjam`
--
ALTER TABLE `detail_pinjam`
  ADD KEY `no_pinjam` (`no_pinjam`),
  ADD KEY `id_cd` (`id_cd`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `log_cd`
--
ALTER TABLE `log_cd`
  ADD PRIMARY KEY (`id_log`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pinjam`
--
ALTER TABLE `pinjam`
  ADD PRIMARY KEY (`no_pinjam`),
  ADD KEY `id_booking` (`id_booking`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `temp`
--
ALTER TABLE `temp`
  ADD KEY `id_kategori` (`genre`),
  ADD KEY `id_cd` (`id_cd`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `cd_film`
--
ALTER TABLE `cd_film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `log_cd`
--
ALTER TABLE `log_cd`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `cd_film`
--
ALTER TABLE `cd_film`
  ADD CONSTRAINT `cd_film_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id`);

--
-- Ketidakleluasaan untuk tabel `temp`
--
ALTER TABLE `temp`
  ADD CONSTRAINT `temp_ibfk_1` FOREIGN KEY (`genre`) REFERENCES `kategori` (`id`),
  ADD CONSTRAINT `temp_ibfk_2` FOREIGN KEY (`id_cd`) REFERENCES `cd_film` (`id`);

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
