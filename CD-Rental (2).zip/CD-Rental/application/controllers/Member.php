<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(['ModelUser', 'ModelBooking']);
    }

    public function index()
    {
        $this->_login();
    }

    private function _login()
    {
        $email = htmlspecialchars($this->input->post('email', true));
        $password = $this->input->post('password', true);
        $user = $this->ModelUser->cekData(['email' => $email])->row_array();

        if ($user) {
            if ($user['is_active'] == 1) {
                if (password_verify($password, $user['password'])) {
                    $data = [
                        'email' => $user['email'],
                        'role_id' => $user['role_id'],
                        'id_user' => $user['id'],
                        'nama' => $user['nama']
                    ];
                    $this->session->set_userdata($data);
                    redirect('home');
                } else {
                    $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Password salah!!</div>');
                }
            } else {
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">User belum diaktivasi!!</div>');
            }
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Email tidak terdaftar!!</div>');
        }
        redirect('home');
    }

    public function booking()
    {
        $id_user = $this->session->userdata('id_user');
        $id = ['bo.id_user' => $id_user];
        $data['booking'] = $this->ModelBooking->joinOrder($id)->result();

        $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['image'] = $user['image'];
        $data['user'] = $user['nama'];
        $data['email'] = $user['email'];
        $data['tanggal_input'] = $user['tanggal_input'];

        $data['jumlah_booking'] = $this->ModelBooking->getDataWhere('temp', ['email_user' => $this->session->userdata('email')])->num_rows();

        $dtb = $this->ModelBooking->showtemp(['id_user' => $id_user])->num_rows();
        if ($dtb < 1) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Tidak ada CD di keranjang</div>');
            redirect(base_url());
        } else {
            $data['temp'] = $this->db->query("SELECT image, judul_cd, tahun, id_cd FROM temp WHERE id_user='$id_user'")->result_array();
        }

        $data['judul'] = "Data Booking";
        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('booking/data-booking', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }

    public function hapusbooking()
    {
        $id_cd = $this->uri->segment(3);
        $id_user = $this->session->userdata('id_user');
        $this->ModelBooking->deleteData(['id_cd' => $id_cd, 'id_user' => $id_user], 'temp');
        $kosong = $this->db->get_where('temp', ['id_user' => $id_user])->num_rows();

        if ($kosong < 1) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Tidak ada CD di keranjang.</div>');
            redirect(base_url());
        } else {
            redirect('booking');
        }
    }

    public function tambahKeKeranjang($id_cd)
    {
        if (!$this->session->userdata('id_user')) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">Silakan login terlebih dahulu.</div>');
            redirect('autentifikasi');
        }

        $cd = $this->db->get_where('cd_film', ['id' => $id_cd])->row();
        $id_user = $this->session->userdata('id_user');

        if ($this->db->get_where('temp', ['id_user' => $id_user, 'id_cd' => $id_cd])->num_rows() > 0) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-warning">CD sudah ada di keranjang Anda.</div>');
            redirect('home');
        }

        if ($this->db->get_where('temp', ['id_user' => $id_user])->num_rows() >= 3) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-warning">Maksimal 3 CD dalam keranjang.</div>');
            redirect('home');
        }

        $data = [
            'id_cd' => $id_cd,
            'judul_cd' => $cd->judul_cd,
            'id_user' => $id_user,
            'email_user' => $this->session->userdata('email'),
            'tgl_booking' => date('Y-m-d H:i:s'),
            'image' => $cd->image,
            'tahun' => $cd->tahun,
            'genre' => $cd->id_kategori
        ];

        $this->db->insert('temp', $data);
        $this->session->set_flashdata('pesan', '<div class="alert alert-success">CD berhasil ditambahkan ke keranjang.</div>');
        redirect('home');
    }

    public function pilihDurasi()
    {
        $id_user = $this->session->userdata('id_user');
        $id_cd_terpilih = $this->input->post('cd_terpilih');

        if (!$id_cd_terpilih) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">Pilih setidaknya 1 CD untuk dibooking.</div>');
            redirect('booking');
        }

        $this->session->set_userdata('cd_terpilih', $id_cd_terpilih);
        $cd_ids = implode(',', array_map('intval', $id_cd_terpilih));

        $userData = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['user'] = $userData['nama'];
        $data['judul'] = "Konfirmasi dan Pembayaran";
        $data['harga_per_hari'] = 3000;
        $data['jumlah_booking'] = $this->ModelBooking->getDataWhere('temp', ['email_user' => $this->session->userdata('email')])->num_rows();

        $data['cds'] = $this->db->query("
            SELECT cd.*, t.id_cd 
            FROM temp t 
            JOIN cd_film cd ON cd.id = t.id_cd 
            WHERE t.id_user = '$id_user' 
            AND t.id_cd IN ($cd_ids)
        ")->result_array();

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('booking/form-bayar', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }

    public function prosesBayar()
    {
        $id_user = $this->session->userdata('id_user');
        $durasi = $this->input->post('durasi');
        $metode = $this->input->post('metode_pembayaran');
        $harga_per_hari = 3000;
        $cd_terpilih = $this->session->userdata('cd_terpilih');

        if (!$cd_terpilih || empty($cd_terpilih)) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">Tidak ada CD yang dipilih untuk booking.</div>');
            redirect('booking');
        }

        $total = count($cd_terpilih) * $harga_per_hari * $durasi;
        $id_booking = $this->ModelBooking->kodeOtomatis('booking', 'id_booking');

        $this->ModelBooking->insertData('booking', [
            'id_booking' => $id_booking,
            'tgl_booking' => date('Y-m-d H:i:s'),
            'batas_ambil' => date('Y-m-d', strtotime("+$durasi days")),
            'id_user' => $id_user,
            'durasi' => $durasi,
            'total_bayar' => $total,
            'status_pembayaran' => 'Menunggu Pembayaran',
            'metode_pembayaran' => $metode
        ]);

        foreach ($cd_terpilih as $id_cd) {
            $this->ModelBooking->insertData('booking_detail', [
                'id_booking' => $id_booking,
                'id_cd' => $id_cd
            ]);
            $this->db->delete('temp', ['id_user' => $id_user, 'id_cd' => $id_cd]);
        }

        $this->session->unset_userdata('cd_terpilih');
        redirect('member/instruksi/' . $id_booking);
    }
    public function uploadBukti($id_booking)
    {
        // Pastikan booking valid
        $booking = $this->db->get_where('booking', ['id_booking' => $id_booking])->row_array();
        if (!$booking) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">Data booking tidak ditemukan.</div>');
            redirect('member/riwayat');
        }

        // Upload file bukti pembayaran
        $config['upload_path'] = './assets/img/bukti/';
        $config['allowed_types'] = 'jpg|jpeg|png|pdf';
        $config['max_size'] = 2048;
        $config['file_name'] = 'bukti_' . time();

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('bukti')) {
            $upload_data = $this->upload->data();
            $this->db->set('bukti_pembayaran', $upload_data['file_name']);
            // Jangan ubah status_pembayaran di sini
            $this->db->where('id_booking', $id_booking);
            $this->db->update('booking');

            $this->session->set_flashdata('pesan', '<div class="alert alert-success">Bukti pembayaran berhasil diunggah. Silakan tunggu konfirmasi dari admin.</div>');
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">' . $this->upload->display_errors() . '</div>');
        }

        redirect('member/riwayat');
    }


    public function instruksi($id_booking)
    {
        $data['judul'] = "Instruksi Pembayaran";
        $data['booking'] = $this->db->get_where('booking', ['id_booking' => $id_booking])->row_array();
        $data['items'] = $this->db->query("
            SELECT c.*
            FROM booking_detail d
            JOIN cd_film c ON d.id_cd = c.id
            WHERE d.id_booking = '$id_booking'
        ")->result_array();

        $data['jumlah_booking'] = $this->ModelBooking->getDataWhere('temp', ['email_user' => $this->session->userdata('email')])->num_rows();

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('booking/instruksi-pembayaran', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }

    public function info()
    {
        $id_user = $this->session->userdata('id_user');
        $last_booking = $this->db->query("
            SELECT id_booking FROM booking 
            WHERE id_user = '$id_user' 
            ORDER BY tgl_booking DESC 
            LIMIT 1
        ")->row();

        if (!$last_booking) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-warning">Tidak ada data booking ditemukan.</div>');
            redirect('booking');
        }

        $id_booking = $last_booking->id_booking;

        $data['user'] = $this->session->userdata('nama');
        $data['judul'] = "Selesai Booking";
        $data['jumlah_booking'] = $this->ModelBooking->getDataWhere('temp', ['email_user' => $this->session->userdata('email')])->num_rows();

        $data['items'] = $this->db->query("
            SELECT c.*, k.kategori AS genre, bo.id_booking, bo.tgl_booking, bo.total_bayar, bo.durasi 
            FROM booking bo
            JOIN booking_detail d ON d.id_booking = bo.id_booking
            JOIN cd_film c ON d.id_cd = c.id
            JOIN kategori k ON k.id = c.id_kategori
            WHERE bo.id_booking = '$id_booking'
        ")->result_array();

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('booking/info-booking', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }

    public function daftar()
    {
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required', ['required' => 'Nama belum diisi!']);
        $this->form_validation->set_rules('alamat', 'Alamat Lengkap', 'required', ['required' => 'Alamat belum diisi!']);
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user.email]', [
            'required' => 'Email belum diisi!',
            'valid_email' => 'Format email salah!',
            'is_unique' => 'Email sudah terdaftar!'
        ]);
        $this->form_validation->set_rules('password1', 'Password', 'required|min_length[3]|matches[password2]', [
            'required' => 'Password belum diisi!',
            'min_length' => 'Password terlalu pendek!',
            'matches' => 'Password tidak cocok!'
        ]);
        $this->form_validation->set_rules('password2', 'Ulangi Password', 'required|matches[password1]');

        if ($this->form_validation->run() == false) {
            redirect('home');
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'alamat' => $this->input->post('alamat', true),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'image' => 'default.jpg',
                'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
                'role_id' => 2,
                'is_active' => 1,
                'tanggal_input' => time()
            ];
            $this->ModelUser->simpanData($data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-message">Akun berhasil dibuat, silakan login!</div>');
            redirect('home');
        }
    }

    public function riwayat()
    {
        $id_user = $this->session->userdata('id_user');
        $data['judul'] = 'Riwayat Booking';
        $data['user'] = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();

        $data['booking'] = $this->db->query("
            SELECT bo.*, COUNT(d.id_cd) AS jumlah_cd 
            FROM booking bo 
            LEFT JOIN booking_detail d ON bo.id_booking = d.id_booking 
            WHERE bo.id_user = '$id_user' 
            GROUP BY bo.id_booking 
            ORDER BY bo.tgl_booking DESC
        ")->result_array();

        $data['jumlah_booking'] = $this->ModelBooking->getDataWhere('temp', ['email_user' => $this->session->userdata('email')])->num_rows();

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('member/riwayat-booking', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }

    public function myProfil()
    {
        $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();

        $data = [
            'judul' => 'Profil Saya',
            'image' => $user['image'],
            'user' => $user['nama'],
            'email' => $user['email'],
            'tanggal_input' => $user['tanggal_input']
        ];

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('member/index', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }

    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('role_id');
        $this->session->unset_userdata('id_user');
        $this->session->unset_userdata('nama');

        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-message">Anda telah logout!</div>');
        redirect('home');
    }
}
