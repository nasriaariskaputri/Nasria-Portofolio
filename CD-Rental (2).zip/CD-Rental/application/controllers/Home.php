<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(['ModelUser', 'ModelCd']);
    }

    public function index()
    {
        $keyword = $this->input->get('keyword');

        // Jika ada pencarian
        if ($keyword) {
            $this->db->like('judul_cd', $keyword);
            $cd = $this->db->get('cd_film')->result();
        } else {
            // Default tampilkan semua CD
            $cd = $this->ModelCd->getCd()->result();  // Pastikan ModelCd->getCd() mengarah ke cd_film
        }

        $data = [
            'judul' => "Katalog CD",
            'cd' => $cd,
        ];

        // Ambil nama user jika login
        if ($this->session->userdata('email')) {
            $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
            $data['user'] = $user;
        } else {
            $data['user'] = 'Pengunjung';
        }

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('cd/daftar_cd', $data);
        $this->load->view('templates/templates-user/modal', $data);
        $this->load->view('templates/templates-user/footer', $data);
    }

    public function detailCd()
    {
        $id = $this->uri->segment(3);
        $cd = $this->ModelCd->joinKategoriCd(['cd_film.id' => $id])->result();

        if (!$cd) show_404();

        foreach ($cd as $fields) {
            $data['judul'] = $fields->judul_cd;
            $data['sutradara'] = $fields->sutradara;
            $data['kategori'] = $fields->kategori;
            $data['tahun'] = $fields->tahun;
            $data['kode'] = $fields->kode;
            $data['gambar'] = $fields->image;
            $data['dipinjam'] = $fields->dipinjam;
            $data['dibooking'] = $fields->dibooking;
            $data['stok'] = $fields->stok;
            $data['id'] = $id;
        }

        $data['user'] = $this->session->userdata('nama') ?? "Pengunjung";
        $data['title'] = "Detail CD";

        $this->load->view('templates/templates-user/header', $data);
        $this->load->view('cd/detail_cd', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('templates/templates-user/footer');
    }
}
