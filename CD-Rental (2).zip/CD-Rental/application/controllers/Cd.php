<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cd extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();
        $this->load->model('ModelCd');       // ✅ Tambahkan ini
        $this->load->model('ModelUser');     // ✅ Tambahkan juga ini karena kamu pakai $this->modeluser
    }


    public function index()
    {
        $data['judul'] = 'Data CD';
        $data['user'] = $this->modeluser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['cd'] = $this->ModelCd->getCd()->result_array();
        $data['kategori'] = $this->ModelCd->getKategori()->result_array();

        $this->form_validation->set_rules('judul_cd', 'Judul CD', 'required|min_length[3]');
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('tahun', 'Tahun', 'required|numeric|min_length[4]|max_length[4]');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');

        $config['upload_path'] = './assets/img/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['file_name'] = 'cd_' . time();

        $this->load->library('upload', $config);

        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar', $data);
            $this->load->view('admin/topbar', $data);
            $this->load->view('cd/index', $data);
            $this->load->view('admin/footer');
        } else {
            $gambar = $this->upload->do_upload('image') ? $this->upload->data('file_name') : '';

            $data = [
                'judul_cd' => $this->input->post('judul_cd', true),
                'id_kategori' => $this->input->post('id_kategori', true),
                'tahun' => $this->input->post('tahun', true),
                'stok' => $this->input->post('stok', true),
                'dibooking' => 0,
                'image' => $gambar
            ];

            $this->ModelCd->simpanCd($data);
            redirect('cd');
        }
    }

    public function hapusCd()
    {
        $where = ['id' => $this->uri->segment(3)];
        $this->ModelCd->hapusCd($where);
        redirect('cd');
    }

    public function ubahCd()
    {
        $data['judul'] = 'Ubah Data CD';
        $data['user'] = $this->modeluser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['cd'] = $this->ModelCd->cdWhere(['id' => $this->uri->segment(3)])->row_array();
        $kategori = $this->ModelCd->joinKategoriCd(['cd_film.id' => $this->uri->segment(3)])->row_array();

        $data['id'] = $kategori['id_kategori'];
        $data['k'] = $kategori['kategori'];
        $data['kategori'] = $this->ModelCd->getKategori()->result_array();

        $this->form_validation->set_rules('judul_cd', 'Judul CD', 'required|min_length[3]');
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('tahun', 'Tahun', 'required|numeric|min_length[4]|max_length[4]');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');

        $config['upload_path'] = './assets/img/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['file_name'] = 'cd_' . time();
        $this->load->library('upload', $config);

        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar', $data);
            $this->load->view('admin/topbar', $data);
            $this->load->view('cd/ubah_cd', $data);
            $this->load->view('admin/footer');
        } else {
            $gambar = $this->upload->do_upload('image')
                ? $this->upload->data('file_name')
                : $this->input->post('old_pict', TRUE);

            $data = [
                'judul_cd' => $this->input->post('judul_cd', true),
                'id_kategori' => $this->input->post('id_kategori', true),
                'tahun_rilis' => $this->input->post('tahun', true),
                'stok' => $this->input->post('stok', true),
                'image' => $gambar
            ];

            $this->ModelCd->updateCd($data, ['id' => $this->input->post('id')]);
            redirect('cd');
        }
    }

    // === KATEGORI ===
    public function kategori()
    {
        $data['judul'] = 'Kategori CD';
        $data['user'] = $this->modeluser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['kategori'] = $this->ModelCd->getKategori()->result_array();

        $this->form_validation->set_rules('kategori', 'Kategori', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar', $data);
            $this->load->view('admin/topbar', $data);
            $this->load->view('cd/kategori', $data);
            $this->load->view('admin/footer');
        } else {
            $this->ModelCd->simpanKategori(['kategori' => $this->input->post('kategori', true)]);
            redirect('cd/kategori');
        }
    }

    public function ubahKategori()
    {
        $data['judul'] = 'Ubah Kategori';
        $data['user'] = $this->modeluser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['kategori'] = $this->ModelCd->kategoriWhere(['id' => $this->uri->segment(3)])->row_array();

        $this->form_validation->set_rules('kategori', 'Kategori', 'required|min_length[3]');

        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar', $data);
            $this->load->view('admin/topbar', $data);
            $this->load->view('cd/ubah_kategori', $data);
            $this->load->view('admin/footer');
        } else {
            $this->ModelCd->updateKategori(['id' => $this->input->post('id')], ['kategori' => $this->input->post('kategori')]);
            redirect('cd/kategori');
        }
    }

    public function hapusKategori()
    {
        $this->ModelCd->hapusKategori(['id' => $this->uri->segment(3)]);
        redirect('cd/kategori');
    }
}
