<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login(); // pastikan helper login tersedia
        $this->load->model(['ModelUser', 'ModelCd', 'ModelBooking']);

        // Ambil data user dari session
        $this->user = $this->ModelUser->cekData([
            'email' => $this->session->userdata('email')
        ])->row_array();

        // Batasi akses hanya untuk admin
        if ($this->user['role_id'] != 1) {
            redirect('home'); // atau redirect ke 'member' jika punya halaman khusus member
        }
    }


    public function index()
    {
        $data['judul'] = 'Dashboard';
        $data['user'] = $this->user;
        $data['anggota'] = $this->ModelUser->getUserLimit()->result_array();
        $data['cd_film'] = $this->ModelCd->getCd()->result_array();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar', $data);
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('admin/footer');
    }
    public function anggota()
    {
        $data['judul'] = 'Data Anggota';
        $data['user'] = $this->ModelUser->cekData([
            'email' => $this->session->userdata('email')
        ])->row_array();

        // Tambahkan ini
        $email = $this->session->userdata('email');
        $data['jumlah_booking'] = $this->ModelBooking->getDataWhere('temp', ['email_user' => $email])->num_rows();

        $this->db->where('role_id', 1); // admin
        $data['anggota'] = $this->db->get('user')->result_array();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar', $data);
        $this->load->view('admin/topbar', $data);
        $this->load->view('user/anggota', $data);
        $this->load->view('templates/templates-user/modal');
        $this->load->view('admin/footer');
    }
    // ✅ Tampilkan data pembayaran
    public function dataPembayaran()
    {
        $data['judul'] = 'Data Pembayaran';
        $data['user'] = $this->user;

        // Ambil parameter tanggal dari input GET
        $tanggal = $this->input->get('tanggal');

        // Mulai query
        $this->db->select('booking.*, user.nama, user.email');
        $this->db->from('booking');
        $this->db->join('user', 'user.id = booking.id_user');

        // Jika filter tanggal diisi
        if (!empty($tanggal)) {
            $this->db->where('DATE(tgl_booking)', $tanggal);
        }

        $this->db->order_by('tgl_booking', 'DESC');
        $data['pembayaran'] = $this->db->get()->result_array();

        $data['tanggal'] = $tanggal; // kirim ke view agar value input tetap terisi

        // Load view
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar', $data);
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/data-pembayaran', $data);
        $this->load->view('admin/footer');
    }


    // ✅ Ubah status jadi "Sudah Bayar"
    public function ubahStatusBayar($id_booking)
    {
        $this->db->set('status_pembayaran', 'Sudah Bayar');
        $this->db->where('id_booking', $id_booking);
        $this->db->update('booking');

        $this->session->set_flashdata('pesan', '<div class="alert alert-success">Status pembayaran berhasil diubah menjadi <b>Sudah Bayar</b>.</div>');
        redirect('admin/dataPembayaran');
    }
    public function ubahAnggota($id)
    {
        $this->load->model('ModelUser');

        $data['judul'] = 'Ubah Data Anggota';
        $data['user'] = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
        $data['anggota'] = $this->ModelUser->userWhere(['id' => $id])->row_array();

        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar', $data);
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/ubah_anggota', $data);
            $this->load->view('admin/footer');
        } else {
            $updateData = [
                'nama' => $this->input->post('nama'),
                'email' => $this->input->post('email'),
            ];

            $this->ModelUser->updateUser($updateData, ['id' => $id]);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success">Data anggota berhasil diubah!</div>');
            redirect('admin/anggota');
        }
    }
}
