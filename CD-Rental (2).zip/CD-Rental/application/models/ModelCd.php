<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ModelCd extends CI_Model
{
    // manajemen cd
    public function getCd()
    {
        return $this->db->get('cd_film'); // sudah benar
    }

    public function cdWhere($where)
    {
        return $this->db->get_where('cd_film', $where); // ganti cd jadi cd_film
    }

    public function simpanCd($data = null)
    {
        $this->db->insert('cd_film', $data); // ganti cd jadi cd_film
    }

    public function updateCd($data = null, $where = null)
    {
        $this->db->update('cd_film', $data, $where); // ganti cd jadi cd_film
    }

    public function hapusCd($where = null)
    {
        $this->db->delete('cd_film', $where); // ganti cd jadi cd_film
    }

    public function total($field, $where)
    {
        $this->db->select_sum($field);
        if (!empty($where) && count($where) > 0) {
            $this->db->where($where);
        }
        $this->db->from('cd_film'); // ganti cd jadi cd_film
        return $this->db->get()->row($field);
    }

    // manajemen kategori cd
    public function getKategori()
    {
        return $this->db->get('kategori');
    }

    public function kategoriWhere($where)
    {
        return $this->db->get_where('kategori', $where);
    }

    public function simpanKategori($data = null)
    {
        $this->db->insert('kategori', $data);
    }

    public function hapusKategori($where = null)
    {
        $this->db->delete('kategori', $where);
    }

    public function updateKategori($where = null, $data = null)
    {
        $this->db->update('kategori', $data, $where);
    }

    // join kategori cd
    public function joinKategoriCd($where)
    {
        $this->db->from('cd_film');
        $this->db->join('kategori', 'kategori.id = cd_film.id_kategori');
        $this->db->where($where);
        return $this->db->get();
    }
}
