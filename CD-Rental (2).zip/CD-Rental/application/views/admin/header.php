<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>CD Rental |<?= $judul; ?></title>
    <!-- Custom fonts for this template-->
    <link href="<?= base_url('assets/') ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        /* === SIDEBAR === */
        .custom-sidebar {
            background-color: #001f3f !important;
            /* Navy */
        }

        .custom-sidebar .nav-link span,
        .custom-sidebar .sidebar-brand-text,
        .custom-sidebar .nav-link {
            color: #fff !important;
            font-weight: bold;
        }

        .custom-sidebar .nav-link.active {
            background-color: #003366 !important;
            color: #ffffff !important;
        }

        /* === TOPBAR === */
        .custom-topbar {
            background-color: #001f3f !important;
        }
    </style>

</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">