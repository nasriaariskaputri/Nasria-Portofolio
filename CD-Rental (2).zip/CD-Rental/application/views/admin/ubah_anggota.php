<div class="container-fluid">
    <h3><?= $judul; ?></h3>
    <form method="post" action="">
        <div class="form-group">
            <label for="nama">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama"
                value="<?= $anggota['nama']; ?>" required>
        </div>

        <div class="form-group">
            <label for="email">Alamat Email</label>
            <input type="email" class="form-control" id="email" name="email"
                value="<?= $anggota['email']; ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="<?= base_url('admin/anggota'); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>