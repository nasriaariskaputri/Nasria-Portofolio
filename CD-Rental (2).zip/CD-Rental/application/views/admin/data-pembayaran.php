<div class="container-fluid">
    <h4 class="mb-4"><?= $judul; ?></h4>

    <?= $this->session->flashdata('pesan'); ?>
    <form method="get" action="<?= base_url('admin/dataPembayaran'); ?>" class="form-inline mb-3">
        <label for="tanggal" class="mr-2">Filter Tanggal Booking:</label>
        <input type="date" name="tanggal" id="tanggal" class="form-control mr-2" value="<?= set_value('tanggal', $tanggal); ?>">
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="<?= base_url('admin/dataPembayaran'); ?>" class="btn btn-secondary ml-2">Reset</a>
    </form>
</div>


<div class="table-responsive">
    <table class="table table-bordered table-striped" id="table-datatable">
        <thead class="thead-dark">
            <tr>
                <th>#</th>
                <th>Nama Anggota</th>
                <th>Email</th>
                <th>ID Booking</th>
                <th>Tanggal Booking</th>
                <th>Durasi (hari)</th>
                <th>Total Bayar</th>
                <th>Status</th>
                <th>Metode</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1;
            foreach ($pembayaran as $b) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $b['nama']; ?></td>
                    <td><?= $b['email']; ?></td>
                    <td><?= $b['id_booking']; ?></td>
                    <td><?= date('d-m-Y H:i', strtotime($b['tgl_booking'])); ?></td>
                    <td><?= $b['durasi']; ?></td>
                    <td>Rp <?= number_format($b['total_bayar'], 0, ',', '.'); ?></td>
                    <td>
                        <span class="badge <?= $b['status_pembayaran'] == 'Sudah Bayar' ? 'badge-success' : 'badge-warning'; ?>">
                            <?= $b['status_pembayaran']; ?>
                        </span>
                    </td>
                    <td><?= $b['metode_pembayaran']; ?></td>
                    <td>
                        <?php if ($b['status_pembayaran'] != 'Sudah Bayar') : ?>
                            <a href="<?= base_url('admin/ubahStatusBayar/' . $b['id_booking']); ?>"
                                class="btn btn-sm btn-success"
                                onclick="return confirm('Yakin ingin mengubah status menjadi Sudah Bayar?')">
                                Tandai Sudah Bayar
                            </a>
                        <?php else : ?>
                            <i class="text-muted">Lunas</i>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</div>