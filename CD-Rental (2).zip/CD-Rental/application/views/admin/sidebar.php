<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-dark accordion custom-sidebar" id="accordionSidebar">



    <!-- Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('admin'); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-compact-disc"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Rental CD</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('admin'); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Data CD -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('cd'); ?>">
            <i class="fas fa-fw fa-compact-disc"></i>
            <span>Data CD</span></a>
    </li>

    <!-- Kategori -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('cd/kategori'); ?>">
            <i class="fas fa-fw fa-tags"></i>
            <span>Kategori CD</span></a>
    </li>

    <!-- Anggota -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('admin/anggota'); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Data Anggota</span></a>
    </li>
    <!-- Pembayaran -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('admin/dataPembayaran'); ?>">
            <i class="fas fa-fw fa-money-check-alt"></i>
            <span>Data Pembayaran</span>
        </a>
    </li>


    <!-- Logout -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('home'); ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>


</ul>
<!-- End of Sidebar -->