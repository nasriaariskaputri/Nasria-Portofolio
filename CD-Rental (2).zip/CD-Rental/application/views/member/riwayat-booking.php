<div class="container mt-4">
    <h3>Riwayat Booking</h3>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID Booking</th>
                <th>Tanggal Booking</th>
                <th>Durasi</th>
                <th>Total Bayar</th>
                <th>Status</th>
                <th>Jumlah CD</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($booking)): ?>
                <?php foreach ($booking as $b): ?>
                    <tr>
                        <td><?= $b['id_booking']; ?></td>
                        <td><?= date('d M Y H:i', strtotime($b['tgl_booking'])); ?></td>
                        <td><?= $b['durasi']; ?> hari</td>
                        <td>Rp <?= number_format($b['total_bayar'], 0, ',', '.'); ?></td>
                        <td>
                            <span class="badge badge-<?= $b['status_pembayaran'] == 'Lunas' ? 'success' : 'warning'; ?>">
                                <?= $b['status_pembayaran']; ?>
                            </span>
                        </td>
                        <td><?= $b['jumlah_cd']; ?> CD</td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">Belum ada riwayat booking</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>