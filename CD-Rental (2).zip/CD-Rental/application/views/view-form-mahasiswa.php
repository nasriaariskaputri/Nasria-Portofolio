<html>
<head>
 <title>Form Input Data Mahasiswa</title>
</head>
<body>
 <center>
 <form action="<?= base_url('mahasiswa/cetak'); ?>"
method="post">
 <table>
 <tr>
 <th colspan="5">
 Form Input Data Mata Kuliah
 </th>
 </tr>
 <tr>
 <td colspan="5">
 <hr>
 </td>
 </tr>
 <tr>
 <th>NIM</th>
 <th>:</th>
 <td>
 <input type="text" name="nim" id="nim">
 </td>
 </tr>
 <tr>
 <th>Nama Lengkap</th>
 <td>:</td>
 <td>
 <input type="text" name="nama" id="nama">
 </td>
 </tr>
 <tr>
 <th>Program Studi</th>
 <td>:</td>
 <td>
 <input type="text" name="program" id="program">
 </td>
 </tr>
 <tr>
 <th>Semester</th>
 <td>:</td>
 <td>
 <select name="sms" id="sms">
 <option value="">Pilih Semester</option>
 <option value="2">1</option>
 <option value="3">2</option>
 <option value="4">3</option>
 <option value="5">4</option>
 <option value="6">5</option>
 <option value="7">6</option>
 <option value="8">7</option>
 <option value="9">8</option>
 <tr>
 <th>IPK</th>
 <td>:</td>
 <td>
 <input type="text" name="ipk" id="ipk">
 </td>
 </tr>
 </select>
 </td>
 </tr>
 <tr>
 <td colspan="5" align="center">
 <input type="submit" value="Submit">
 </td>
 </tr>
 </table>
 </form>
 </center>
</body>
</html>
