<div class="container-fluid">
    <?= $this->session->flashdata('pesan'); ?>
    <div class="row">
        <div class="col-lg-3">
            <?php if (validation_errors()) { ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php } ?>
            <?= $this->session->flashdata('pesan'); ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Anggota</th>
                        <th scope="col">Email</th>
                        <th scope="col">Pilihan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $w = 1;
                    foreach ($anggota as $a) { ?>
                        <tr>
                            <th scope="row"><?= $w++; ?></th>
                            <td><?= $a['nama']; ?></td>
                            <td><?= $a['email']; ?></td>
                            <td>
                                <a href="<?= base_url('admin/ubahAnggota/' . $a['id']); ?>" class="badge badge-info">
                                    <i class="fas fa-edit"></i> Ubah
                                </a>

                                <a href="<?= base_url('/') . $a['id']; ?>" onclick="returnconfirm('Kamu yakin akan menghapus <?= $judul . ' ' . $a['nama']; ?>?');" class="badge badge-danger"><i class="fas fa-trash"></i>
                                    Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->