<div class="container">
    <center>
        <table>
            <tr>
                <td>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover" id="table-datatable">
                            <tr>
                                <th>No.</th>
                                <th>CD</th>
                                <th>Genre</th>
                                <th>Tahun Rilis</th>
                            </tr>
                            <?php
                            $no = 1;
                            foreach ($items as $i) {
                            ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <img src="<?= base_url('assets/img/upload/' . $i['image']); ?>" class="rounded" alt="No Picture" width="10%">
                                        <br><?= $i['judul_cd'] ?? $i['judul']; ?>
                                    </td>
                                    <td nowrap><?= $i['genre']; ?></td>
                                    <td nowrap><?= $i['tahun']; ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <hr>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="btn btn-sm btn-outline-danger" onclick="information('Waktu pengambilan CD maksimal 1x24 jam dari booking!')" href="<?= base_url('booking/exportToPdf/' . $this->session->userdata('id_user')); ?>">
                        <span class="far fa-lg fa-fw fa-file-pdf"></span> Cetak PDF
                    </a>
                </td>
            </tr>
        </table>
    </center>
</div>