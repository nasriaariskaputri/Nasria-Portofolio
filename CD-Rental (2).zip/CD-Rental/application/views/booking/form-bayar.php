<div class="container mt-5">
    <h3 class="text-center mb-4">Form Pembayaran Booking CD</h3>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <?= $this->session->flashdata('pesan'); ?>
            <form action="<?= base_url('member/prosesBayar'); ?>" method="post">


                <div class="form-group mb-3">
                    <label for="durasi">Lama Sewa (hari)</label>
                    <input type="number" name="durasi" id="durasi" class="form-control" value="1" min="1" required onchange="updateTotal()">
                </div>

                <div class="form-group mb-3">
                    <label for="harga_per_hari">Harga per Hari</label>
                    <div class="input-group">
                        <div class="input-group-text">Rp</div>
                        <input type="text" id="harga_per_hari" class="form-control" value="<?= number_format($harga_per_hari, 0, ',', '.'); ?>" disabled>
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label for="total_bayar">Total Bayar</label>
                    <input type="text" id="total_bayar_display" class="form-control" disabled>
                    <input type="hidden" name="total_bayar" id="total_bayar">
                </div>

                <div class="form-group mb-4">
                    <label for="metode">Metode Pembayaran</label>
                    <select name="metode_pembayaran" id="metode" class="form-control" required>
                        <option value="">-- Pilih Metode --</option>
                        <option value="transfer_bank">Transfer Bank</option>
                        <option value="ewallet_ovo">OVO</option>
                        <option value="ewallet_dana">DANA</option>
                        <option value="ewallet_gopay">GoPay</option>
                    </select>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-success">Bayar dan Selesaikan Booking</button>
                </div>

            </form>
        </div>
    </div>
</div>

<script>
    const hargaPerHari = <?= $harga_per_hari; ?>;

    function updateTotal() {
        const durasi = parseInt(document.getElementById('durasi').value) || 1;
        const total = durasi * hargaPerHari;

        document.getElementById('total_bayar').value = total;
        document.getElementById('total_bayar_display').value = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(total);
    }

    updateTotal(); // otomatis saat halaman pertama kali dibuka
</script>