<div class="container mt-5">
    <h3 class="text-center">Instruksi Pembayaran</h3>
    <div class="alert alert-info mt-4">
        <p>Silakan transfer ke rekening berikut:</p>
        <ul>
            <li><strong>Bank BCA</strong>: 1234567890 a.n. CD Rental</li>
            <li><strong>OVO</strong>: 0812-3456-7890 a.n. CD Rental</li>
            <li><strong>DANA</strong>: 0812-9999-8888 a.n. CD Rental</li>
        </ul>
        <p>Setelah melakukan pembayaran, upload bukti pembayaran di bawah ini.</p>
    </div>

    <form action="<?= base_url('member/uploadBukti/' . $booking['id_booking']); ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="bukti">Upload Bukti Pembayaran</label>
            <input type="file" name="bukti" class="form-control" required>
        </div>
        <div class="text-center mt-3">
            <button type="submit" class="btn btn-primary">Sudah Selesai Pembayaran</button>
        </div>
    </form>
</div>