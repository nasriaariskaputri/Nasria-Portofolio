<div class="container">
    <center>
        <form action="<?= base_url('member/pilihDurasi'); ?>" method="post">
            <div class="table-responsive full-width">
                <table class="table table-bordered table-striped table-hover" id="table-datatable">
                    <thead>
                        <tr>
                            <th>Pilih</th>
                            <th>Gambar</th>
                            <th>Judul</th>
                            <th>Tahun</th>
                            <th>Aksi</th> <!-- Tambahkan kolom aksi -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($temp as $cd) : ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="cd_terpilih[]" value="<?= $cd['id_cd']; ?>">
                                </td>
                                <td><img src="<?= base_url('assets/img/upload/' . $cd['image']); ?>" width="50"></td>
                                <td><?= $cd['judul_cd']; ?></td>
                                <td><?= $cd['tahun']; ?></td>
                                <td>
                                    <!-- Tombol Hapus Per Item -->
                                    <a href="<?= base_url('member/hapusbooking/' . $cd['id_cd']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus CD ini dari keranjang?')">
                                        Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn btn-success mt-3">Lanjut ke Pembayaran</button>
        </form>

        <hr>

        <a class="btn btn-sm btn-outline-primary" href="<?= base_url(); ?>">
            <span class="fas fw fa-play"></span> Lanjutkan Booking CD
        </a>
    </center>
</div>