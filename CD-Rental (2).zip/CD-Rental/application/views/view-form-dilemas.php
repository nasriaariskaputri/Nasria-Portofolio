<html>
<head>
 <title>Form Input Data Siswa</title>
</head>
<body>
 <center>
 <form action="<?= base_url('dilemas/cetak'); ?>"
method="post">
 <table>
 <tr>
 <th colspan="5">
 Form Input Data Siswa
 </th>
 </tr>
 <tr>
 <td colspan="5">
 <hr>
 </td>
 </tr>
 <tr>
 <th>Nama Siswa</th>
 <th>:</th>
 <td>
 <input type="text" name="nama" id="nama">
 </td>
 </tr>
 <tr>
 <th>NIS</th>
 <td>:</td>
 <td>
 <input type="text" name="nis" id="nis">
 </td>
 </tr>
 <tr>
 <th>Kelas</th>
 <td>:</td>
 <td>
 <input type="text" name="kls" id="kls">
 </td>
 </tr>
 <tr>
 <th>Tanggal Lahir</th>
 <td>:</td>
 <td>
 <input type="text" name="tgl" id="tgl">
 </td>
 </tr>
 <tr>
 <th>Tempat Lahir</th>
 <td>:</td>
 <td>
 <input type="text" name="tl" id="tl">
 </td>
 </tr>
 <tr>
 <th>Alamat</th>
 <td>:</td>
 <td>
 <input type="text" name="alamat" id="alamat">
 </td>
 </tr>
 <tr>
 <th>Jenis Kelamin
 <td>:</td>
 <td>
 <input type="radio" name="jenis_kelamin" id="jenis_kelamin" value="Laki-laki"> Laki-laki
 <input type="radio" name="jenis_kelamin" id="jenis_kelamin" value="Perempuan"> Perempuan
</td>
</tr>
<tr>
 <th>Agama</th>
 <td>:</td>
 <td>
 <select name="agama" id="agama">
 <option value="">Pilih Agama</option>
 <option value="2">Islam</option>
 <option value="3">Kristen</option>
 <option value="4">Hindu</option>
 <option value="5">Budha</option>
 <option value="6">Konghucu</option>
 <option value="7">Protestan</option>
 <option value="8">Katholik</option>
 <tr>
 <tr>
 <td colspan="8" align="center">
 <input type="submit" value="Submit">
 </td>
 </tr>
 </table>
 </form>
 </center>
</body>
</html>
