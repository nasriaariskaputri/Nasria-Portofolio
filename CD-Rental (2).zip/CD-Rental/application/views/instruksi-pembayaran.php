<div class="container mt-5">
    <h3 class="text-center mb-4">Instruksi Pembayaran</h3>

    <p><strong>Kode Booking:</strong> <?= $booking['id_booking']; ?></p>
    <p><strong>Total Bayar:</strong> Rp <?= number_format($booking['total_bayar'], 0, ',', '.'); ?></p>
    <p><strong>Metode Pembayaran:</strong> <?= ucfirst(str_replace('_', ' ', $booking['metode_pembayaran'])); ?></p>
    <p><strong>Status:</strong> <?= $booking['status_pembayaran']; ?></p>

    <hr>
    <h5>Silakan transfer ke:</h5>
    <?php if ($booking['metode_pembayaran'] == 'ewallet_ovo'): ?>
        <p>Nomor OVO: 08xxxxxxxxxx<br>Atas Nama: CD Rental</p>
    <?php elseif ($booking['metode_pembayaran'] == 'ewallet_dana'): ?>
        <p>Nomor DANA: 08xxxxxxxxxx<br>Atas Nama: CD Rental</p>
    <?php elseif ($booking['metode_pembayaran'] == 'transfer_bank'): ?>
        <p>Rekening BCA: 1234567890<br>Atas Nama: CD Rental</p>
    <?php endif; ?>

    <a href="<?= base_url(); ?>" class="btn btn-primary mt-3">Kembali ke Beranda</a>
</div>