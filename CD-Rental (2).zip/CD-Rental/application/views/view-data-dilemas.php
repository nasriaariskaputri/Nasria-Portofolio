<html>
<head>
<title>Tampil Data Siswa</title>
</head>
<body>
 <center>
 <table>
 <tr>
 <th colspan="8">
 Tampil Data Siswa
 </th>
 </tr>
 <tr>
 <td colspan="8">
 <hr>
 </td>
 </tr>
 <tr>
 <th>Nama Lengkap</th>
 <th>:</th>
 <td>
 <?= $nama; ?>
 </td>
 </tr>
 <tr>
 <td>Nis</td>
 <td>:</td>
 <td>
 <?= $nis; ?>
 </td>
 </tr>
 <tr>
 <td>Kelas</td>
 <td>:</td>
 <td>
 <?= $kls; ?>
 </td>
 </tr>
 <tr>
 <td>Tanggal Lahir</td>
 <td>:</td>
 <td>
 <?= $tgl; ?>
 </td>
 </tr>
 <tr>
 <td>Alamat</td>
 <td>:</td>
 <td>
 <?= $alamat; ?>
 </td>
 </tr>
 <tr>
 <td>Jenis Kelamin</td>
 <td>:</td>
 <td>
 <?= $jenis_kelamin; ?>
 </td>
 </tr>
 <tr>
 <td>Agama</td>
 <td>:</td>
 <td>
 <?= $agama; ?>
 </td>
 </tr>
 <tr>
 <td colspan="8" align="center">
 <a href="<?= base_url('dilemas'); 
?>">Kembali</a>
 </td>
 </tr>
 </table>
 </center>
</body>
</html>