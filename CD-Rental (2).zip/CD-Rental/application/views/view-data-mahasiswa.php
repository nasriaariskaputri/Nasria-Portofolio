<html>
<head>
<title>Tampil Data Mahasiswa</title>
</head>
<body>
 <center>
 <table>
 <tr>
 <th colspan="5">
 Tampil Data Mahasiswa
 </th>
 </tr>
 <tr>
 <td colspan="5">
 <hr>
 </td>
 </tr>
 <tr>
 <th>NIM</th>
 <th>:</th>
 <td>
 <?= $nim; ?>
 </td>
 </tr>
 <tr>
 <td>Nama Lengkap</td>
 <td>:</td>
 <td>
 <?= $nama; ?>
 </td>
 </tr>
 <tr>
 <td>Program Studi</td>
 <td>:</td>
 <td>
 <?= $program; ?>
 </td>
 </tr>
 <tr>
 <td>Semester</td>
 <td>:</td>
 <td>
 <?= $sms; ?>
 </td>
 </tr>
 <tr>
 <td>IPK</td>
 <td>:</td>
 <td>
 <?= $ipk; ?>
 </td>
 </tr>
 <tr>
 <td colspan="5" align="center">
 <a href="<?= base_url('mahasiswa'); 
?>">Kembali</a>
 </td>
 </tr>
 </table>
 </center>
</body>
</html>