<div class="container-fluid">
    <form method="post" action="<?= base_url('cd/ubahCd'); ?>" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $cd['id']; ?>">

        <div class="form-group">
            <label for="judul_cd">Judul CD</label>
            <input type="text" class="form-control" id="judul_cd" name="judul_cd" value="<?= $cd['judul_cd']; ?>" required>
        </div>

        <div class="form-group">
            <label for="id_kategori">Kategori</label>
            <select name="id_kategori" id="id_kategori" class="form-control" required>
                <?php foreach ($kategori as $k) : ?>
                    <option value="<?= $k['id']; ?>" <?= $k['id'] == $id ? 'selected' : ''; ?>>
                        <?= $k['kategori']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="tahun">Tahun Rilis</label>
            <input type="number" class="form-control" name="tahun" id="tahun" value="<?= $cd['tahun']; ?>" required>
        </div>

        <div class="form-group">
            <label for="stok">Stok</label>
            <input type="number" class="form-control" name="stok" id="stok" value="<?= $cd['stok']; ?>" required>
        </div>

        <div class="form-group">
            <label for="image">Gambar CD</label><br>
            <img src="<?= base_url('assets/img/upload/' . $cd['image']); ?>" width="100"><br><br>
            <input type="file" name="image" id="image" class="form-control">
            <input type="hidden" name="old_pict" value="<?= $cd['image']; ?>">
        </div>

        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="<?= base_url('cd'); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>