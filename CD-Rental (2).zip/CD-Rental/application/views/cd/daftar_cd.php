<div class="container mt-5">
    <h3 class="text-center mb-4"><?= $judul; ?></h3>

    <!-- 🔍 Form Pencarian -->
    <form method="GET" action="<?= base_url('home'); ?>" class="mb-4">
        <div class="input-group">
            <input type="text" name="keyword" class="form-control" placeholder="Cari CD berdasarkan judul..." value="<?= $this->input->get('keyword'); ?>">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">Cari</button>
            </div>
        </div>
    </form>

    <div class="row">
        <?php if (!empty($cd)): ?>
            <?php foreach ($cd as $film): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow">
                        <img src="<?= base_url('assets/img/upload/' . $film->image); ?>" class="card-img-top" alt="<?= $film->judul_cd ?>" style="height: 200px; object-fit: cover;">
                        <div class="card-body">
                            <h5 class="card-title"><?= $film->judul_cd; ?></h5>
                            <p class="card-text"><strong>Sutradara:</strong> <?= $film->sutradara; ?></p>
                            <p class="card-text"><strong>Penerbit:</strong> <?= $film->penerbit; ?></p>
                            <p class="card-text"><strong>Tahun:</strong> <?= $film->tahun; ?></p>
                            <p class="card-text"><strong>Stok:</strong> <?= $film->stok; ?> | <strong>Dipinjam:</strong> <?= $film->dipinjam; ?></p>
                        </div>
                        <div class="card-footer text-center">
                            <a href="<?= base_url('home/detailCd/' . $film->id); ?>" class="btn btn-primary btn-sm">Lihat Detail</a>
                            <a href="<?= base_url('booking/tambahKeKeranjang/' . $film->id); ?>" class="btn btn-success btn-sm">Booking</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <div class="alert alert-warning">
                    <?= $this->input->get('keyword') ? 'CD dengan judul "' . $this->input->get('keyword') . '" tidak ditemukan.' : 'Belum ada CD/film yang tersedia.'; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>