<!-- Begin Page Content -->
<div class="container-fluid">
    <?= $this->session->flashdata('pesan'); ?>

    <div class="row">
        <div class="col-lg-12">
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>

            <a href="#" class="btn btn-primary mb-3" data-toggle="modal" data-target="#cdBaruModal">
                <i class="fas fa-film"></i> Tambah CD Baru
            </a>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Judul</th>
                        <th>Tahun Rilis</th>
                        <th>Stok</th>
                        <th>Dipinjam</th>
                        <th>Dibooking</th>
                        <th>Gambar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($cd as $c) : ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $c['judul_cd']; ?></td>
                            <td><?= $c['tahun']; ?></td>
                            <td><?= $c['stok']; ?></td>
                            <td><?= $c['dipinjam']; ?></td>
                            <td><?= $c['dibooking']; ?></td>
                            <td>
                                <img src="<?= base_url('assets/img/upload/' . $c['image']); ?>" class="img-fluid img-thumbnail" width="80">
                            </td>
                            <td>
                                <a href="<?= base_url('cd/ubahCd/' . $c['id']); ?>" class="badge badge-info">
                                    <i class="fas fa-edit"></i> Ubah
                                </a>
                                <a href="<?= base_url('cd/hapusCd/' . $c['id']); ?>" onclick="return confirm('Yakin ingin menghapus <?= $c['judul_cd']; ?>?');" class="badge badge-danger">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>
<!-- End of Main Content -->

<!-- Modal Tambah CD -->
<div class="modal fade" id="cdBaruModal" tabindex="-1" role="dialog" aria-labelledby="cdBaruModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?= base_url('cd'); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="cdBaruModalLabel">Tambah CD</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" name="judul_cd" class="form-control" placeholder="Judul CD">
                    </div>

                    <div class="form-group">
                        <select name="id_kategori" class="form-control">
                            <option value="">Pilih Kategori</option>
                            <?php foreach ($kategori as $k) : ?>
                                <option value="<?= $k['id']; ?>"><?= $k['kategori']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <select name="tahun" class="form-control">
                            <option value="">Tahun Rilis</option>
                            <?php for ($i = date('Y'); $i >= 1980; $i--) : ?>
                                <option value="<?= $i; ?>"><?= $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="number" name="stok" class="form-control" placeholder="Jumlah Stok">
                    </div>

                    <div class="form-group">
                        <input type="file" name="image" class="form-control">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan CD</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End of Modal -->