<div class="x_panel" align="center">
    <div class="x_content">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="thumbnail" style="width: 100%;">
                    <img src="<?= base_url('assets/img/upload/' . $gambar); ?>" style="max-width:100%; max-height: 300px;" alt="CD Image">
                    <div class="caption mt-3">
                        <h5 class="text-center"><?= $judul ?></h5>
                        <table class="table table-bordered table-sm mt-3">
                            <tr>
                                <th scope="row">Judul CD</th>
                                <td><?= $judul; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Tahun Rilis</th>
                                <td><?= substr($tahun, 0, 4) ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Genre</th>
                                <td><?= $kategori ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Dibooking</th>
                                <td><?= $dibooking ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Stok</th>
                                <td><?= $stok ?></td>
                            </tr>
                        </table>

                        <div class="text-center">
                            <a class="btn btn-outline-primary" href="<?= base_url('booking/tambahKeKeranjang/' . $id); ?>">
                                <i class="fas fa-shopping-cart"></i> Tambah ke Keranjang
                            </a>
                            <button class="btn btn-outline-secondary" onclick="window.history.back();">
                                <i class="fas fa-reply"></i> Kembali
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>