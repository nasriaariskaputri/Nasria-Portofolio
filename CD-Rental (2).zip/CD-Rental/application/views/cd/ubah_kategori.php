<div class="container-fluid">

    <?= $this->session->flashdata('pesan'); ?>

    <form method="post" action="<?= base_url('cd/ubahKategori'); ?>">
        <input type="hidden" name="id" value="<?= $kategori['id']; ?>">

        <div class="form-group">
            <label for="kategori">Nama Kategori</label>
            <input type="text" class="form-control" id="kategori" name="kategori"
                value="<?= $kategori['kategori']; ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="<?= base_url('cd/kategori'); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>